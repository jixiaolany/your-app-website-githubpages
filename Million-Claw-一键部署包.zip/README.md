# Million Claw AI助手平台 - 一键部署包

## 🚀 快速开始

### 系统要求
- Windows 7/8/10/11
- Node.js 16+ (推荐18+)
- 至少500MB可用磁盘空间
- 稳定的网络连接

### 安装步骤

1. **解压文件**
   将本ZIP文件解压到任意目录（建议不要放在系统盘）

2. **运行启动脚本**
   双击运行 `start.bat` 文件

3. **等待安装完成**
   脚本会自动：
   - 安装Node.js依赖包
   - 创建数据目录
   - 启动后端服务器
   - 启动前端界面

4. **访问控制台**
   在浏览器中打开: http://localhost:5173

## 📋 功能特性

### ✅ 核心功能
- **本地AI助手**: 完全运行在本地设备
- **数据安全**: 所有数据保存在本地
- **隐私保护**: 无需上传到云端
- **一键部署**: 下载即用，无需配置

### 🔧 技术特性
- **后端服务器**: Node.js + Express
- **前端界面**: Vue.js + Vite
- **数据库**: SQLite本地数据库
- **数据上报**: 可选上报到GitHub Issues

### 📊 数据管理
- 本地SQLite数据库
- 自动数据备份
- 数据加密存储
- 隐私合规检查

## ⚙️ 配置说明

### 环境配置
编辑 `config/.env` 文件进行配置：

```
# 应用配置
APP_NAME="Million Claw"
VERSION="1.0.0"

# 服务器配置
SERVER_PORT=3000

# 数据上报配置
REPORT_ENDPOINT="https://你的系统地址/api/receive"
REPORT_INTERVAL=3600

# GitHub配置（可选）
GITHUB_USERNAME="你的GitHub用户名"
GITHUB_TOKEN="你的GitHub Token"
```

## 🔗 相关链接

- **官方网站**: https://jixiaolany.github.io/your-app-website-githubpages/
- **GitHub仓库**: https://github.com/jixiaolany/your-app-website-githubpages
- **问题反馈**: 通过GitHub Issues提交

## 🆘 常见问题

### Q: 启动时显示"未检测到Node.js"
A: 请先安装Node.js：https://nodejs.org/

### Q: 前端页面无法访问
A: 确保后端服务器已启动（http://localhost:3000）

### Q: 数据上报失败
A: 检查网络连接和GitHub Token配置

### Q: 如何备份数据
A: 数据自动备份到 `backups/` 目录

## 📞 技术支持

如有问题，请访问官方网站获取帮助。

---

© 2026 Million Claw Team. 保留所有权利。
