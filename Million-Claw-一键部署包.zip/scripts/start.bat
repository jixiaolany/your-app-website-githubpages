@echo off
echo ========================================
echo      Million Claw AI助手平台
echo ========================================
echo.
echo 🚀 正在启动 Million Claw...
echo.

REM 检查Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo ❌ 未检测到Node.js
    echo 💡 访问: https://nodejs.org/
    pause
    exit /b 1
)

echo ✅ 检测到Node.js
echo 📦 正在安装依赖...
call npm install

if not exist "data" mkdir data
if not exist "backups" mkdir backups

echo 🚀 启动服务器...
echo 📡 本地地址: http://localhost:3000
echo 🌐 前端地址: http://localhost:5173
echo.

start cmd /k "node server.js"
timeout /t 2 /nobreak >nul
start cmd /k "npm run dev"

echo ✅ Million Claw 启动成功！
echo 🔗 请在浏览器中打开: http://localhost:5173
echo.
pause