const express = require('express');
const app = express();
const PORT = process.env.SERVER_PORT || 3000;

app.use(express.json());

app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    app: 'Million Claw',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

app.listen(PORT, () => {
  console.log(`🚀 Million Claw 服务器启动: http://localhost:${PORT}`);
});