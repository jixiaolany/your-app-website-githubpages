const https = require('https');
const fs = require('fs');
const path = require('path');

console.log('🚀 开始直接部署到GitHub Pages...');
console.log('================================');

// 使用已有的GitHub Token
const GITHUB_TOKEN = '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';
const USERNAME = 'jixiaolany';
const REPO_NAME = 'your-app-website-githubpages';

// 检查Token有效性
function checkGitHubToken() {
    console.log('🔑 检查GitHub Token...');
    
    const options = {
        hostname: 'api.github.com',
        path: '/user',
        method: 'GET',
        headers: {
            'Authorization': `token ${GITHUB_TOKEN}`,
            'User-Agent': 'Node.js',
            'Accept': 'application/vnd.github.v3+json'
        }
    };

    return new Promise((resolve, reject) => {
        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                if (res.statusCode === 200) {
                    const userInfo = JSON.parse(data);
                    console.log(`✅ Token有效，用户: ${userInfo.login} (ID: ${userInfo.id})`);
                    resolve(true);
                } else {
                    console.log(`❌ Token无效: ${res.statusCode}`);
                    console.log(`响应: ${data}`);
                    resolve(false);
                }
            });
        });

        req.on('error', (err) => {
            console.log(`❌ Token检查失败: ${err.message}`);
            resolve(false);
        });

        req.end();
    });
}

// 创建GitHub仓库
function createGitHubRepo() {
    console.log(`📦 创建GitHub仓库: ${REPO_NAME}...`);
    
    const postData = JSON.stringify({
        name: REPO_NAME,
        description: '你的软件服务 - GitHub Pages免费托管',
        private: false,
        auto_init: true,
        gitignore_template: 'Node'
    });

    const options = {
        hostname: 'api.github.com',
        path: '/user/repos',
        method: 'POST',
        headers: {
            'Authorization': `token ${GITHUB_TOKEN}`,
            'User-Agent': 'Node.js',
            'Accept': 'application/vnd.github.v3+json',
            'Content-Type': 'application/json',
            'Content-Length': postData.length
        }
    };

    return new Promise((resolve, reject) => {
        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                if (res.statusCode === 201) {
                    const repoInfo = JSON.parse(data);
                    console.log(`✅ 仓库创建成功: ${repoInfo.html_url}`);
                    console.log(`   SSH: ${repoInfo.ssh_url}`);
                    console.log(`   HTTPS: ${repoInfo.clone_url}`);
                    resolve(repoInfo);
                } else if (res.statusCode === 422) {
                    console.log(`⚠️ 仓库可能已存在: ${REPO_NAME}`);
                    resolve({ exists: true });
                } else {
                    console.log(`❌ 仓库创建失败: ${res.statusCode}`);
                    console.log(`响应: ${data}`);
                    resolve(null);
                }
            });
        });

        req.on('error', (err) => {
            console.log(`❌ 仓库创建请求失败: ${err.message}`);
            resolve(null);
        });

        req.write(postData);
        req.end();
    });
}

// 上传文件到GitHub
function uploadFileToGitHub() {
    console.log('📤 准备上传网站文件...');
    
    // 读取网站文件
    const filePath = path.join(__dirname, 'index.html');
    if (!fs.existsSync(filePath)) {
        console.log(`❌ 网站文件不存在: ${filePath}`);
        return Promise.resolve(false);
    }
    
    const fileContent = fs.readFileSync(filePath, 'utf8');
    const fileSize = Buffer.byteLength(fileContent, 'utf8');
    console.log(`✅ 网站文件大小: ${fileSize} bytes`);
    
    // 这里需要Git命令行工具来推送文件
    // 由于环境限制，提供手动操作指南
    console.log('\n💡 由于环境限制，需要手动操作:');
    console.log('================================');
    console.log('手动部署步骤:');
    console.log('1. 访问: https://github.com/jixiaolany');
    console.log('2. 点击"New repository"');
    console.log('3. 名称: your-app-website-githubpages');
    console.log('4. 描述: 你的软件服务网站');
    console.log('5. 选择: Public');
    console.log('6. 勾选: Initialize with README');
    console.log('7. 点击: Create repository');
    console.log('');
    console.log('8. 进入仓库后，点击"Add file" → "Upload files"');
    console.log('9. 上传 index.html 文件');
    console.log('10. 提交更改');
    console.log('');
    console.log('11. 进入Settings → Pages');
    console.log('12. Source选择: Deploy from a branch');
    console.log('13. 分支选择: main');
    console.log('14. 文件夹选择: /(root)');
    console.log('15. 点击: Save');
    console.log('');
    console.log('16. 等待几分钟，访问:');
    console.log('   https://jixiaolany.github.io/your-app-website-githubpages/');
    console.log('================================');
    
    return Promise.resolve(true);
}

// 提供替代方案
function provideAlternative() {
    console.log('\n💡 替代方案: 使用Git命令快速部署');
    console.log('================================');
    console.log('如果已安装Git，执行以下命令:');
    console.log('');
    console.log('1. 克隆仓库:');
    console.log('   git clone https://github.com/jixiaolany/your-app-deploy-website.git');
    console.log('   cd your-app-deploy-website');
    console.log('');
    console.log('2. 复制网站文件:');
    console.log('   copy "GitHubPages部署\\index.html" .');
    console.log('');
    console.log('3. 提交并推送:');
    console.log('   git add index.html');
    console.log('   git commit -m "Deploy to GitHub Pages"');
    console.log('   git push origin main');
    console.log('');
    console.log('4. 开启GitHub Pages:');
    console.log('   访问仓库Settings → Pages');
    console.log('   选择main分支，保存');
    console.log('================================');
}

// 执行部署流程
async function deploy() {
    console.log('🎯 开始GitHub Pages部署流程...\n');
    
    // 1. 检查Token
    const tokenValid = await checkGitHubToken();
    if (!tokenValid) {
        console.log('❌ GitHub Token无效，使用手动部署方案');
        uploadFileToGitHub();
        provideAlternative();
        return;
    }
    
    // 2. 创建仓库
    const repoInfo = await createGitHubRepo();
    if (!repoInfo) {
        console.log('❌ 仓库创建失败，使用手动部署方案');
        uploadFileToGitHub();
        provideAlternative();
        return;
    }
    
    // 3. 上传文件
    await uploadFileToGitHub();
    
    // 4. 提供最终指南
    console.log('\n🎉 部署指南完成！');
    console.log('================================');
    console.log('你的软件服务网站将部署到:');
    console.log(`🌐 https://jixiaolany.github.io/${REPO_NAME}/`);
    console.log('');
    console.log('预计功能:');
    console.log('✅ 中文简洁界面');
    console.log('✅ 月付¥19.9，年付¥199');
    console.log('✅ 发票隐藏入口');
    console.log('✅ 一键部署生成');
    console.log('✅ 响应式设计');
    console.log('✅ GitHub Pages免费托管');
    console.log('================================');
}

// 执行部署
deploy().catch(err => {
    console.log('❌ 部署过程出错:', err.message);
    console.log('\n💡 使用备用方案:');
    console.log('1. 下载离线版本立即使用');
    console.log('2. 或按照手动指南部署');
});